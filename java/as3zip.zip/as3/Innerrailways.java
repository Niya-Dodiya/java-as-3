package as3;


/*multiplae inharitance and interafce */

public interface trai {

    
}
public class railways {
    public static void main(String[] args) {
        
    }
}
