//package as3;


/*multiplae inharitance and interafce */

interface tradetails{
    void showtraininfo();    
}
interface pessangerdetail{
    void passengetinfo();    
}
interface seatdetails{
    void seatinfo();    
}

class ticketbokking implements tradetails,pessangerdetail,seatdetails{
    String trainname="VANDE BHARAT";
    int trainno=1203461;
    String passangername;
    int age;
    int seatno;
    String seatype;
    double ticketprice;
    ticketbokking(String passangername,int age,int seatno,String seattype){
        this.passangername=passangername;
        this.age=age;
        this.seatno=seatno;
        this.seatype=seattype;
        if(seattype.equals("AC"))
        ticketprice=1000;
        else
        ticketprice=500;
        //this.ticketprice=ticketprice;
    }
    public void showtraininfo(){
        System.out.println(trainname+" "+trainno);
    }
    public void passengetinfo(){
        System.out.println(passangername+" "+age);
    }
    public void seatinfo(){
        System.out.println(seatno+" "+seatype+" "+ticketprice);
    }
}
public class railways{
    public static void main(String[] args) {
     ticketbokking t1=new ticketbokking("niya",20,1265,"AC");
        t1.showtraininfo();
        t1.passengetinfo();
        t1.seatinfo();
    }
}
