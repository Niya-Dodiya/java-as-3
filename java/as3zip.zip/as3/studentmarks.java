//package as3;
/* hyriarchical inharitance */
class collage{
    String clgname="ks";
    int clgcode=01;

    void displayclginfo(){
        System.out.println(clgname);
        System.out.println(clgcode);
    }
}
class student extends collage{
     int marks[] ={88,54,98};
     int total;
     char grade;

     void calculatetotalmarks(){
        for(int mark:marks){
            total+=mark;
        }
     }

     void calculategrade(){
        grade=total/3 >= 85 ? 'A' : 'B';
     }
    
     void displayinfo(){
        displayclginfo();
        calculatetotalmarks();
        calculategrade();
        System.out.println(total);
        System.out.println(grade);
     }
}
public class studentmarks{
    public static void main(String[] args) {
        student s1=new student();
        s1.displayinfo();
    }
}
