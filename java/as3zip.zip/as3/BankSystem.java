//package as3;
/*abstract class methos overriding */
abstract class BankAccount {
    int accountNumber;
    String accountHolderName;
    double balance;

    BankAccount(int accountNumber, String accountHolderName, double balance) {
        this.accountNumber = accountNumber;
        this.accountHolderName = accountHolderName;
        this.balance = balance;
    }

    abstract void withdraw(double amount);

    void deposit(double amount) {
        balance += amount;
    }

    void displayAccountDetails() {
        System.out.println("Account Holder: " + accountHolderName + ", Balance: " + balance);
    }
}

class SavingsAccount extends BankAccount {
    double interestRate = 5.0;

    SavingsAccount(int accountNumber, String accountHolderName, double balance) {
        super(accountNumber, accountHolderName, balance);
    }

    void withdraw(double amount) {
        if (balance - amount >= 500) balance -= amount;
        else System.out.println("Insufficient Balance");
    }
}

public class BankSystem {
    public static void main(String[] args) {
        SavingsAccount acc = new SavingsAccount(12345, "John Doe", 2000);
        acc.withdraw(500);
        acc.displayAccountDetails();
    }
}